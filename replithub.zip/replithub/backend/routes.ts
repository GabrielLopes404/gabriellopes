// Referenced from blueprints: javascript_database, javascript_websocket
import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import multer from "multer";
import path from "path";
import fs from "fs";
import { authMiddleware, requireRole, generateToken, verifyToken, type AuthRequest } from "./middleware/auth";
import {
  insertUserSchema, insertClientSchema, insertProjectSchema,
  insertTaskSchema, insertAnnouncementSchema, insertTransactionSchema,
  insertTimesheetEntrySchema, insertChatMessageSchema
} from "@shared/schema";

const upload = multer({
  dest: "uploads/",
  limits: { fileSize: 10 * 1024 * 1024 },
});

if (!fs.existsSync("uploads")) {
  fs.mkdirSync("uploads");
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(data.username);
      if (existingUser) {
        return res.status(400).json({ message: "Usuário já existe" });
      }

      const hashedPassword = await bcrypt.hash(data.password, 10);
      const user = await storage.createUser({
        ...data,
        password: hashedPassword,
      });

      const { password: _, ...userWithoutPassword } = user;
      const token = generateToken(user);

      res.json({ user: userWithoutPassword, token });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;

      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }

      const { password: _, ...userWithoutPassword } = user;
      const token = generateToken(user);

      res.json({ user: userWithoutPassword, token });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;

      if (!email) {
        return res.status(400).json({ message: "Email é obrigatório" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.json({ message: "Se o email existir, você receberá um link de recuperação" });
      }

      const resetToken = require('crypto').randomBytes(32).toString('hex');
      const expiry = new Date(Date.now() + 3600000);

      await storage.setResetToken(user.id, resetToken, expiry);

      if (process.env.NODE_ENV !== 'production') {
        console.log(`\n┌─────────────────────────────────────────────────────────────────┐`);
        console.log(`│ 🔐 RECUPERAÇÃO DE SENHA (MODO DESENVOLVIMENTO)                 │`);
        console.log(`├─────────────────────────────────────────────────────────────────┤`);
        console.log(`│ Email: ${email.padEnd(56)}│`);
        console.log(`│ Token: ${resetToken.padEnd(55)}│`);
        console.log(`│ Link:  ${req.protocol}://${req.get('host')}/reset-password?token=${resetToken}                               │`);
        console.log(`├─────────────────────────────────────────────────────────────────┤`);
        console.log(`│ ⚠️  PRODUÇÃO: Implementar envio via email/SMS                  │`);
        console.log(`└─────────────────────────────────────────────────────────────────┘\n`);
      }

      res.json({ 
        message: "Se o email existir, você receberá instruções de recuperação. Verifique seu email."
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { token, newPassword } = req.body;

      if (!token || !newPassword) {
        return res.status(400).json({ message: "Token e nova senha são obrigatórios" });
      }

      const user = await storage.getUserByResetToken(token);
      if (!user || !user.resetTokenExpiry) {
        return res.status(400).json({ message: "Token inválido ou expirado" });
      }

      if (new Date() > new Date(user.resetTokenExpiry)) {
        return res.status(400).json({ message: "Token expirado" });
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateUser(user.id, { password: hashedPassword });
      await storage.setResetToken(user.id, '', new Date(0));

      res.json({ message: "Senha redefinida com sucesso" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Users routes
  app.get("/api/users", authMiddleware, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Clients routes (Admin e Gerente podem gerenciar, Funcionário pode apenas visualizar)
  app.get("/api/clients", authMiddleware, async (req, res) => {
    try {
      const clients = await storage.getAllClients();
      res.json(clients);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/clients", authMiddleware, requireRole("admin", "gerente"), async (req, res) => {
    try {
      const data = insertClientSchema.parse(req.body);
      const client = await storage.createClient(data);
      res.json(client);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/clients/:id", authMiddleware, requireRole("admin", "gerente"), async (req, res) => {
    try {
      const data = insertClientSchema.partial().parse(req.body);
      const client = await storage.updateClient(req.params.id, data);
      if (!client) {
        return res.status(404).json({ message: "Cliente não encontrado" });
      }
      res.json(client);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/clients/:id", authMiddleware, requireRole("admin", "gerente"), async (req, res) => {
    try {
      await storage.deleteClient(req.params.id);
      res.json({ message: "Cliente removido" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Projects routes (Admin e Gerente podem gerenciar, Funcionário pode apenas visualizar)
  app.get("/api/projects", authMiddleware, async (req, res) => {
    try {
      const projects = await storage.getAllProjects();
      res.json(projects);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/projects", authMiddleware, requireRole("admin", "gerente"), upload.array("files"), async (req, res) => {
    try {
      const data = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(data);

      if (req.files && Array.isArray(req.files)) {
        for (const file of req.files) {
          await storage.createProjectFile({
            projectId: project.id,
            filename: file.originalname,
            filepath: file.path,
            filesize: file.size,
            mimetype: file.mimetype,
          });
        }
      }

      res.json(project);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/projects/:id", authMiddleware, requireRole("admin", "gerente"), async (req, res) => {
    try {
      await storage.deleteProject(req.params.id);
      res.json({ message: "Projeto removido" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Tasks routes
  app.get("/api/tasks", authMiddleware, async (req, res) => {
    try {
      const tasks = await storage.getAllTasks();
      res.json(tasks);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tasks", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const data = insertTaskSchema.parse(req.body);
      const task = await storage.createTask({
        ...data,
        createdById: req.user!.id,
      });
      res.json(task);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/tasks/:id/status", authMiddleware, async (req, res) => {
    try {
      const { status } = req.body;
      const task = await storage.updateTask(req.params.id, { status });
      if (!task) {
        return res.status(404).json({ message: "Tarefa não encontrada" });
      }
      res.json(task);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Announcements routes
  app.get("/api/announcements", authMiddleware, async (req, res) => {
    try {
      const announcements = await storage.getAllAnnouncements();
      res.json(announcements);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/announcements", authMiddleware, requireRole("admin"), async (req: AuthRequest, res) => {
    try {
      const data = insertAnnouncementSchema.parse(req.body);
      const announcement = await storage.createAnnouncement({
        ...data,
        createdById: req.user!.id,
      });
      res.json(announcement);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Transactions routes (Apenas Admin e Gerente podem ver e gerenciar finanças)
  app.get("/api/transactions", authMiddleware, requireRole("admin", "gerente"), async (req, res) => {
    try {
      const transactions = await storage.getAllTransactions();
      res.json(transactions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/transactions", authMiddleware, requireRole("admin", "gerente"), async (req: AuthRequest, res) => {
    try {
      const data = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction({
        ...data,
        createdById: req.user!.id,
      });
      res.json(transaction);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Timesheet routes
  app.get("/api/timesheet", authMiddleware, async (req, res) => {
    try {
      const entries = await storage.getAllTimesheetEntries();
      res.json(entries);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/timesheet", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const data = insertTimesheetEntrySchema.parse(req.body);
      const entry = await storage.createTimesheetEntry({
        ...data,
        userId: req.user!.id,
      });
      res.json(entry);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", authMiddleware, async (req, res) => {
    try {
      const clients = await storage.getAllClients();
      const projects = await storage.getAllProjects();
      const tasks = await storage.getAllTasks();
      const transactions = await storage.getAllTransactions();
      const timesheetEntries = await storage.getAllTimesheetEntries();
      const users = await storage.getAllUsers();

      const totalClients = clients.length;
      const activeProjects = projects.filter(p => p.status === "em_andamento").length;
      const pendingTasks = tasks.filter(t => t.status === "pendente").length;
      const totalRevenue = transactions
        .filter(t => t.tipo === "receita")
        .reduce((acc, t) => acc + Number(t.valor), 0);

      const monthlyRevenue = Array.from({ length: 6 }, (_, i) => {
        const date = new Date();
        date.setMonth(date.getMonth() - i);
        const month = date.toLocaleString("pt-BR", { month: "short" });
        const monthTransactions = transactions.filter(t => {
          const tDate = new Date(t.data);
          return tDate.getMonth() === date.getMonth() && tDate.getFullYear() === date.getFullYear() && t.tipo === "receita";
        });
        const valor = monthTransactions.reduce((acc, t) => acc + Number(t.valor), 0);
        return { mes: month, valor };
      }).reverse();

      const projectsByStatus = [
        { name: "Não Iniciado", value: projects.filter(p => p.status === "nao_iniciado").length },
        { name: "Em Andamento", value: projects.filter(p => p.status === "em_andamento").length },
        { name: "Concluído", value: projects.filter(p => p.status === "concluido").length },
      ];

      const hoursByUser = users.map(user => {
        const userEntries = timesheetEntries.filter(e => e.userId === user.id);
        const horas = userEntries.reduce((acc, e) => acc + Number(e.horasTrabalhadas), 0);
        return { nome: user.nome, horas };
      });

      const financialOverview = Array.from({ length: 6 }, (_, i) => {
        const date = new Date();
        date.setMonth(date.getMonth() - i);
        const month = date.toLocaleString("pt-BR", { month: "short" });
        const monthTransactions = transactions.filter(t => {
          const tDate = new Date(t.data);
          return tDate.getMonth() === date.getMonth() && tDate.getFullYear() === date.getFullYear();
        });
        const receitas = monthTransactions.filter(t => t.tipo === "receita").reduce((acc, t) => acc + Number(t.valor), 0);
        const despesas = monthTransactions.filter(t => t.tipo === "despesa").reduce((acc, t) => acc + Number(t.valor), 0);
        return { mes: month, receitas, despesas };
      }).reverse();

      res.json({
        totalClients,
        activeProjects,
        pendingTasks,
        totalRevenue,
        monthlyRevenue,
        projectsByStatus,
        hoursByUser,
        financialOverview,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const clients = new Map<WebSocket, string>();

  wss.on("connection", (ws) => {
    console.log("Cliente WebSocket conectado");

    ws.on("message", async (message) => {
      try {
        const data = JSON.parse(message.toString());

        if (data.type === "auth") {
          const decoded = verifyToken(data.token);
          if (decoded) {
            clients.set(ws, decoded.id);
            
            const messages = await storage.getAllChatMessages();
            ws.send(JSON.stringify({ type: "history", messages }));
          }
        } else if (data.type === "message") {
          const userId = clients.get(ws);
          if (userId) {
            const chatMessage = await storage.createChatMessage({
              senderId: userId,
              mensagem: data.mensagem,
            });

            wss.clients.forEach((client) => {
              if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({ type: "message", message: chatMessage }));
              }
            });
          }
        }
      } catch (error) {
        console.error("Erro no WebSocket:", error);
      }
    });

    ws.on("close", () => {
      clients.delete(ws);
      console.log("Cliente WebSocket desconectado");
    });
  });

  return httpServer;
}
