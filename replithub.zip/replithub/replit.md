# Lopes Designer Gestão

## Overview

Lopes Designer Gestão is a comprehensive management system designed for design agencies. It provides complete control over projects, clients, finances, tasks, and internal communication through a modern web application. The system features role-based access control (Admin, Manager, Employee), real-time chat via WebSockets, financial tracking, timesheet management, and project file handling.

**Project Status:** ✅ Fully configured and running in Replit environment with modern 2025 UI design.

**Recent Changes (October 28, 2025):**
- Restructured project: separated frontend and backend into distinct folders (/frontend and /backend)
- Updated all configuration files to work with new structure
- Modernized UI with ultra-professional 2025 design (gradient backgrounds, glassmorphism, animations)
- Fixed authentication and database setup
- Added security enforcement for JWT_SECRET in production
- Configured deployment for autoscale production hosting

## User Preferences

Preferred communication style: Simple, everyday language (Portuguese).

## Default Login Credentials

- **Admin**: `admin` / `admin123`
- **Gerente**: `gerente` / `admin123`
- **Funcionário**: `funcionario` / `admin123`

## System Architecture

### Project Structure

**New Folder Organization (October 2025):**
```
├── frontend/          # React frontend application
├── backend/           # Express.js backend API
│   └── shared/        # Shared schemas and types
├── uploads/           # File upload storage
└── attached_assets/   # Project assets
```

### Frontend Architecture

**Location:** `/frontend`

**Framework & Build Tools**
- React 18+ with TypeScript for type-safe component development
- Vite as the build tool and development server with HMR support (port 5000)
- TailwindCSS for styling with ultra-modern 2025 design (gradients, glassmorphism, animations)
- Wouter for lightweight client-side routing

**State Management**
- TanStack Query (React Query) for server state management, caching, and data fetching
- React Context API for global state (authentication, theme)
- Local component state with React hooks

**UI Component System**
- shadcn/ui component library built on Radix UI primitives
- Custom design tokens following Material Design principles
- Brand color palette: blue (light/dark), purple, pink
- Consistent spacing, typography, and elevation system
- Dark mode support via CSS variables and theme context

**Authentication Flow**
- JWT token stored in localStorage
- AuthContext provides user state and authentication methods across the app
- ProtectedRoute wrapper component enforces authentication on protected pages
- Token included in API requests via fetch interceptors

### Backend Architecture

**Location:** `/backend`

**Server Framework**
- Express.js with TypeScript for type-safe API development
- Custom middleware for logging, authentication, and role-based access control
- WebSocket server (ws library) for real-time chat functionality
- Runs on port 5000 (integrated with Vite in development)

**API Design**
- RESTful API endpoints organized by resource (`/api/clients`, `/api/projects`, etc.)
- JWT authentication middleware validates tokens on protected routes
- Role-based authorization middleware (`requireRole`) restricts access by user role
- File upload handling via Multer middleware (local filesystem storage)

**Database Layer**
- Drizzle ORM for type-safe database queries and schema management
- PostgreSQL dialect with Neon serverless driver
- Schema-first design with TypeScript types generated from Drizzle schema
- Connection pooling via @neondatabase/serverless

**Database Schema Design**
- Users table: authentication, roles (admin/gerente/funcionario), password reset tokens
- Clients table: contact information, company details
- Projects table: references client and responsible user, includes status enum, dates, financial values
- Project Files table: file metadata linked to projects
- Tasks table: assignable to users, optionally linked to projects, status tracking
- Transactions table: financial records (receita/despesa), categorized, linked to projects
- Timesheet Entries table: time tracking linked to tasks and projects
- Chat Messages table: real-time messaging with user references
- Announcements table: internal communications with role targeting

**Authentication & Authorization**
- bcrypt for password hashing (10 rounds)
- jsonwebtoken for generating and verifying JWT tokens
- JWT_SECRET enforced in production environment (development uses warning fallback)
- Three-tier role hierarchy: admin (full access), gerente (management), funcionario (limited)
- Middleware chain: authMiddleware validates token → requireRole checks permissions
- Seed users created automatically in database (admin, gerente, funcionario)

### External Dependencies

**Core Runtime**
- Node.js with ES modules
- TypeScript for type safety across the stack

**Database**
- PostgreSQL (via Neon serverless)
- Connection string from `DATABASE_URL` environment variable
- Drizzle Kit for migrations

**File Storage**
- Local filesystem (uploads/ directory)
- Multer for multipart/form-data handling
- 10MB file size limit
- Supported formats: PSD, AI, PNG, etc.
- Future migration path to S3 via abstraction layer

**UI Libraries**
- Radix UI primitives for accessible, unstyled components
- Recharts for data visualization (dashboard charts)
- cmdk for command palette functionality
- Lucide React for iconography

**Real-time Communication**
- WebSocket protocol for bidirectional chat
- ws library on server, native WebSocket API on client
- Authentication via token sent on connection establishment
- Message history loaded on connect, new messages pushed to all connected clients

**Development Tools**
- tsx for running TypeScript directly in development
- esbuild for production builds
- Vite for frontend development with runtime error overlay
- Replit-specific plugins for development environment integration