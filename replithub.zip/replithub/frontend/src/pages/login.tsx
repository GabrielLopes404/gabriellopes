import { useState, useMemo } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Sparkles, Shield, Lock, User, ArrowRight, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erro ao fazer login");
      }

      const data = await response.json();
      login(data.user, data.token);
      
      toast({
        title: "✨ Login realizado!",
        description: `Bem-vindo de volta, ${data.user.nome}!`,
      });
      
      setTimeout(() => {
        setLocation("/dashboard");
      }, 100);
    } catch (error) {
      toast({
        title: "Erro no login",
        description: error instanceof Error ? error.message : "Credenciais inválidas",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-4">
      {/* Background gradiente premium escuro */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900">
        {/* Grid pattern overlay animado */}
        <div 
          className="absolute inset-0 opacity-10 animate-pulse"
          style={{
            backgroundImage: `linear-gradient(rgba(139, 92, 246, 0.15) 1.5px, transparent 1.5px), linear-gradient(90deg, rgba(139, 92, 246, 0.15) 1.5px, transparent 1.5px)`,
            backgroundSize: '60px 60px',
            animation: 'grid-move 20s linear infinite'
          }}
        />
      </div>
      

      {/* Animated gradient orbs de fundo com movimento suave */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -left-40 w-[500px] h-[500px] bg-purple-600/30 rounded-full mix-blend-multiply filter blur-[100px] animate-blob" />
        <div className="absolute -top-40 -right-40 w-[500px] h-[500px] bg-blue-600/30 rounded-full mix-blend-multiply filter blur-[100px] animate-blob delay-1000" />
        <div className="absolute -bottom-40 left-1/2 w-[500px] h-[500px] bg-pink-600/30 rounded-full mix-blend-multiply filter blur-[100px] animate-blob delay-2000" />
      </div>

      {/* Card de login centralizado com animação de entrada */}
      <div className="w-full max-w-md relative z-10">
        {/* Logo com animação de aura multi-camadas */}
        <div className="flex items-center justify-center mb-10">
          <div className="relative group cursor-pointer">
            {/* Camadas de aura animadas com pulsos diferentes */}
            <div className="absolute -inset-12 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 rounded-full opacity-60 blur-3xl group-hover:opacity-90 transition-all duration-700 animate-pulse" 
                 style={{ animationDuration: '3s' }} />
            <div className="absolute -inset-8 bg-gradient-to-r from-purple-500 via-blue-500 to-pink-500 rounded-full opacity-50 blur-2xl animate-pulse" 
                 style={{ animationDuration: '2s', animationDelay: '0.5s' }} />
            <div className="absolute -inset-4 bg-gradient-to-r from-purple-400 via-blue-400 to-pink-400 rounded-full opacity-30 blur-xl animate-pulse"
                 style={{ animationDuration: '1.5s', animationDelay: '1s' }} />
            
            {/* Logo container com rotação suave no hover */}
            <div className="relative flex items-center justify-center w-28 h-28 rounded-full bg-gradient-to-br from-purple-600 via-blue-600 to-pink-600 shadow-2xl transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
              <Sparkles className="h-14 w-14 text-white animate-pulse" style={{ animationDuration: '2s' }} />
            </div>
          </div>
        </div>

        {/* Título com animação de gradiente */}
        <div className="text-center mb-8 space-y-3">
          <h1 className="text-6xl font-bold tracking-tight">
            <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-pink-400 bg-clip-text text-transparent animate-gradient bg-[length:200%_auto]">
              Lopes Designer
            </span>
          </h1>
          <p className="text-slate-300 text-lg font-medium tracking-wide">
            Sistema de Gestão Profissional
          </p>
        </div>

        {/* Card com glassmorphism ultra-premium */}
        <Card className="border-0 shadow-2xl bg-white/[0.02] backdrop-blur-3xl relative overflow-hidden rounded-3xl">
          {/* Card glow effect animado */}
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-blue-500/10 to-pink-500/10 animate-gradient" />
          
          {/* Borda gradiente animada */}
          <div className="absolute inset-0 rounded-3xl p-[1.5px] bg-gradient-to-br from-purple-500/60 via-blue-500/60 to-pink-500/60 animate-gradient bg-[length:200%_auto]">
            <div className="h-full w-full rounded-3xl bg-slate-900/95 backdrop-blur-3xl" />
          </div>


          <CardHeader className="space-y-2 text-center relative z-10 pb-6 pt-8">
            <CardTitle className="text-2xl font-semibold text-white flex items-center justify-center gap-3">
              <Shield className="h-7 w-7 text-purple-400" />
              Acesso ao Sistema
            </CardTitle>
            <CardDescription className="text-slate-300 text-base">
              Entre com suas credenciais para continuar
            </CardDescription>
          </CardHeader>

          <CardContent className="relative z-10 pb-8 px-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Username field com animações refinadas */}
              <div className="space-y-2.5">
                <Label htmlFor="username" className="text-slate-200 font-medium text-sm">
                  Usuário
                </Label>
                <div className="relative group">
                  {/* Glow effect no hover */}
                  <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl opacity-0 group-hover:opacity-30 group-focus-within:opacity-40 blur-lg transition-all duration-500" />
                  <div className="relative flex items-center">
                    <User className="absolute left-4 h-5 w-5 text-slate-500 group-hover:text-purple-400 group-focus-within:text-purple-400 transition-all duration-300" />
                    <Input
                      id="username"
                      type="text"
                      placeholder="Digite seu usuário"
                      value={formData.username}
                      onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                      required
                      className="pl-12 pr-4 h-14 bg-slate-800/60 border-slate-700/50 text-white placeholder:text-slate-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/30 transition-all duration-300 rounded-xl text-base hover:bg-slate-800/80 focus:bg-slate-800/80"
                    />
                  </div>
                </div>
              </div>

              {/* Password field com animações refinadas */}
              <div className="space-y-2.5">
                <Label htmlFor="password" className="text-slate-200 font-medium text-sm">
                  Senha
                </Label>
                <div className="relative group">
                  {/* Glow effect no hover */}
                  <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl opacity-0 group-hover:opacity-30 group-focus-within:opacity-40 blur-lg transition-all duration-500" />
                  <div className="relative flex items-center">
                    <Lock className="absolute left-4 h-5 w-5 text-slate-500 group-hover:text-purple-400 group-focus-within:text-purple-400 transition-all duration-300" />
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Digite sua senha"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      required
                      className="pl-12 pr-12 h-14 bg-slate-800/60 border-slate-700/50 text-white placeholder:text-slate-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/30 transition-all duration-300 rounded-xl text-base hover:bg-slate-800/80 focus:bg-slate-800/80"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 text-slate-500 hover:text-purple-400 transition-all duration-300 hover:scale-110"
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Forgot password link */}
              <div className="flex justify-end">
                <Link 
                  href="/forgot-password" 
                  className="text-sm text-purple-400 hover:text-purple-300 font-medium transition-all duration-300 hover:translate-x-1 inline-block"
                >
                  Esqueceu sua senha?
                </Link>
              </div>

              {/* Submit button com múltiplos efeitos */}
              <Button 
                type="submit" 
                className="w-full h-14 bg-gradient-to-r from-purple-600 via-blue-600 to-pink-600 hover:from-purple-700 hover:via-blue-700 hover:to-pink-700 text-white font-semibold text-base shadow-2xl shadow-purple-500/50 hover:shadow-purple-500/80 transition-all duration-500 transform hover:scale-[1.02] hover:-translate-y-0.5 relative overflow-hidden group rounded-xl"
                disabled={isLoading}
              >
                {/* Button shimmer effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-in-out" />
                
                {/* Button glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 opacity-0 group-hover:opacity-50 blur-xl transition-opacity duration-500" />
                
                <span className="relative flex items-center justify-center gap-2">
                  {isLoading ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Entrando...
                    </>
                  ) : (
                    <>
                      Entrar no Sistema
                      <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                    </>
                  )}
                </span>
              </Button>
            </form>

            {/* Credentials info com design refinado */}
            <div className="mt-8 pt-6 border-t border-slate-700/30">
              <div className="bg-gradient-to-br from-slate-800/40 to-slate-900/40 rounded-2xl p-5 backdrop-blur-sm border border-slate-700/30 hover:border-slate-600/50 transition-all duration-300">
                <p className="text-xs font-semibold text-slate-300 text-center mb-3 flex items-center justify-center gap-2">
                  <span className="text-lg">🔐</span>
                  Credenciais de Teste
                </p>
                <div className="space-y-2 text-xs text-slate-400 text-center font-mono">
                  <div className="flex items-center justify-center gap-2 hover:text-purple-300 transition-colors">
                    <span className="text-purple-400 font-semibold">admin</span> 
                    <span className="text-slate-600">/</span> 
                    <span className="text-blue-400 font-semibold">admin123</span>
                  </div>
                  <div className="flex items-center justify-center gap-2 hover:text-purple-300 transition-colors">
                    <span className="text-purple-400 font-semibold">gerente</span> 
                    <span className="text-slate-600">/</span> 
                    <span className="text-blue-400 font-semibold">admin123</span>
                  </div>
                  <div className="flex items-center justify-center gap-2 hover:text-purple-300 transition-colors">
                    <span className="text-purple-400 font-semibold">funcionario</span> 
                    <span className="text-slate-600">/</span> 
                    <span className="text-blue-400 font-semibold">admin123</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer com animação */}
        <div className="mt-8 text-center">
          <p className="text-slate-400 text-sm font-medium">
            © 2025 Lopes Designer. Todos os direitos reservados.
          </p>
        </div>
      </div>

    </div>
  );
}
